# Source to build xsens mti libraries
Folder extracted by 
1. install mtsdk_linux-x64_2019.2.sh script from xsens
2. navigate to install folder and grab xsens_ros_mti_driver/lib/xspublic directory
3. modify Makefiles in each subdirectory to use c++17 and -fPIC flags
