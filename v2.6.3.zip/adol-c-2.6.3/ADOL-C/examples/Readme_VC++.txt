In order to compile the examples with Visual studio use the solution 
file adolc_examples.sln. This solution builds all 6 documented examples.
Individual examples may be build using their own project file. The project
file from windows/adolc.vcxproj must be added as a Reference for linking
correctly.
