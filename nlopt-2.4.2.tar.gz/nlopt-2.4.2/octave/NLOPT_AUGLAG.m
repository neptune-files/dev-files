% NLOPT_AUGLAG: Augmented Lagrangian method (needs sub-algorithm)
%
% See nlopt_minimize for more information.
function val = NLOPT_AUGLAG
  val = 36;
