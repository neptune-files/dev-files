% NLOPT_LD_TNEWTON: Truncated Newton (local, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_TNEWTON
  val = 15;
