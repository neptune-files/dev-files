/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_KVM_CLOCK_H
#define _ASM_X86_KVM_CLOCK_H

extern struct clocksource kvm_clock;

#endif /* _ASM_X86_KVM_CLOCK_H */
