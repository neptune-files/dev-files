#!/bin/bash
grep -q 'WARNING: bad unlock balance detected'
