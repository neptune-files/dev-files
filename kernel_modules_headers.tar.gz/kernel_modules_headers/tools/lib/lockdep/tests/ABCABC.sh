#!/bin/bash
grep -q 'WARNING: possible circular locking dependency detected'
