#!/bin/bash
grep -q 'WARNING: possible recursive locking detected'
