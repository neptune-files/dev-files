var searchData=
[
  ['kelvin2celsius',['kelvin2celsius',['../group__temperature__convertors.html#gac3abd35c1770b3dcb387a46b813c2874',1,'vn::math::kelvin2celsius(float tempInKelvin)'],['../group__temperature__convertors.html#ga6e4ef8354e6089e716b2d3be6a2b8333',1,'vn::math::kelvin2celsius(double tempInKelvin)']]],
  ['kelvin2fahren',['kelvin2fahren',['../group__temperature__convertors.html#ga660d5bbf0530531c2a8c2e67ec9e48fa',1,'vn::math::kelvin2fahren(float tempInKelvin)'],['../group__temperature__convertors.html#gaa6a52ea01238c0b7a544bc8efe14a404',1,'vn::math::kelvin2fahren(double tempInKelvin)']]]
];
