var searchData=
[
  ['quat',['quat',['../classvn_1_1math_1_1_attitude_f.html#a325a3c5834cb2862656121e1aaa1e1cf',1,'vn::math::AttitudeF']]],
  ['quaternion',['quaternion',['../classvn_1_1sensors_1_1_composite_data.html#a2096dbfbba63dafec9da83b7cf688402',1,'vn::sensors::CompositeData']]],
  ['quaternionmagneticaccelerationandangularratesregister',['QuaternionMagneticAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_quaternion_magnetic_acceleration_and_angular_rates_register.html#a02c42d4b839b4c2bad82614e21918f58',1,'vn::sensors::QuaternionMagneticAccelerationAndAngularRatesRegister']]]
];
