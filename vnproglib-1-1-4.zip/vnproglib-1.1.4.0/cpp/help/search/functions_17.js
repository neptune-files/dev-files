var searchData=
[
  ['xsignalhandlesingle',['XSignalHandleSingle',['../classvn_1_1xplat_1_1_signal_1_1_observer.html#ae98ecf5b4a627b761c0700c6ad573d01',1,'vn::xplat::Signal::Observer']]]
];
