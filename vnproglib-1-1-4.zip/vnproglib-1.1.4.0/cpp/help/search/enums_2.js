var searchData=
[
  ['type',['Type',['../structvn_1_1protocol_1_1uart_1_1_packet.html#ab12e361c05cfb93a80bff21a69ccac30',1,'vn::protocol::uart::Packet']]]
];
