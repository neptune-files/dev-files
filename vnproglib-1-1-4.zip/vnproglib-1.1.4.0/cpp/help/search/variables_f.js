var searchData=
[
  ['quat',['quat',['../structvn_1_1sensors_1_1_quaternion_magnetic_acceleration_and_angular_rates_register.html#a757fbbe3b1df49cd152d772c5980c941',1,'vn::sensors::QuaternionMagneticAccelerationAndAngularRatesRegister']]]
];
