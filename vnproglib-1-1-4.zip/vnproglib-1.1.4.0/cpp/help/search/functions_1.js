var searchData=
[
  ['baudrate',['baudrate',['../classvn_1_1sensors_1_1_vn_sensor.html#a57e41140ab6316d91f83c33c0445dd07',1,'vn::sensors::VnSensor::baudrate()'],['../classvn_1_1xplat_1_1_serial_port.html#a5edbb512f7214776a5523f6f44d7e957',1,'vn::xplat::SerialPort::baudrate()']]],
  ['binaryoutputregister',['BinaryOutputRegister',['../structvn_1_1sensors_1_1_binary_output_register.html#adbecec72c15a2271cc389fefcc0acb38',1,'vn::sensors::BinaryOutputRegister']]]
];
