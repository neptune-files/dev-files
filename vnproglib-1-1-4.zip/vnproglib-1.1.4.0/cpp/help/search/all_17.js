var searchData=
[
  ['x',['x',['../structvn_1_1sensors_1_1_velocity_compensation_status_register.html#a0ad5b0f8235384de97bd5fe1b454f8b8',1,'vn::sensors::VelocityCompensationStatusRegister::x()'],['../structvn_1_1math_1_1vec_3_012_00_01_t_01_4.html#a523d625e85f7a50fab373b07dc161818',1,'vn::math::vec&lt; 2, T &gt;::x()'],['../structvn_1_1math_1_1vec_3_013_00_01_t_01_4.html#a67adcd3c5ca91a560854cd25683f6fb9',1,'vn::math::vec&lt; 3, T &gt;::x()'],['../structvn_1_1math_1_1vec_3_014_00_01_t_01_4.html#afff9854cc12cf9998878b53bb134a703',1,'vn::math::vec&lt; 4, T &gt;::x()']]],
  ['xdot',['xDot',['../structvn_1_1sensors_1_1_velocity_compensation_status_register.html#aa6fba4aa78785985315d3c830866c38d',1,'vn::sensors::VelocityCompensationStatusRegister']]],
  ['xsignalhandlesingle',['XSignalHandleSingle',['../classvn_1_1xplat_1_1_signal_1_1_observer.html#ae98ecf5b4a627b761c0700c6ad573d01',1,'vn::xplat::Signal::Observer']]]
];
