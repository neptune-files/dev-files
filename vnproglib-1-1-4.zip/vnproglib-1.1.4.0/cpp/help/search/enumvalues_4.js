var searchData=
[
  ['wait_5fsignaled',['WAIT_SIGNALED',['../classvn_1_1xplat_1_1_event.html#a5298b1ebb7cf57cd7eccb21c71c290f8a51c9bde89a2e4662508b2759bf1c4c62',1,'vn::xplat::Event']]],
  ['wait_5ftimedout',['WAIT_TIMEDOUT',['../classvn_1_1xplat_1_1_event.html#a5298b1ebb7cf57cd7eccb21c71c290f8ad6f55712876ef2d0744dae7806c235d6',1,'vn::xplat::Event']]]
];
