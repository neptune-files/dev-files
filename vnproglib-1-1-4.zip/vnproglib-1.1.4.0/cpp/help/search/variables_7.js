var searchData=
[
  ['headingmode',['headingMode',['../structvn_1_1sensors_1_1_vpe_basic_control_register.html#a2c270077786fe14d6b00d9b4b8df5eff',1,'vn::sensors::VpeBasicControlRegister']]],
  ['hour',['hour',['../structvn_1_1protocol_1_1uart_1_1_time_utc.html#a91eff6a9496939d514106aa4a5ec0f4f',1,'vn::protocol::uart::TimeUtc']]],
  ['hsimode',['hsiMode',['../structvn_1_1sensors_1_1_magnetometer_calibration_control_register.html#ae8c7815928b8f75555daa1a7f6648820',1,'vn::sensors::MagnetometerCalibrationControlRegister']]],
  ['hsioutput',['hsiOutput',['../structvn_1_1sensors_1_1_magnetometer_calibration_control_register.html#aacb4227d202c0567fb4f4393ba8819a4',1,'vn::sensors::MagnetometerCalibrationControlRegister']]]
];
