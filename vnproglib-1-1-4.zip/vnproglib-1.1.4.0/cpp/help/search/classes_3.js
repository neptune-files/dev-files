var searchData=
[
  ['deltathetaanddeltavelocityconfigurationregister',['DeltaThetaAndDeltaVelocityConfigurationRegister',['../structvn_1_1sensors_1_1_delta_theta_and_delta_velocity_configuration_register.html',1,'vn::sensors']]],
  ['deltathetaanddeltavelocityregister',['DeltaThetaAndDeltaVelocityRegister',['../structvn_1_1sensors_1_1_delta_theta_and_delta_velocity_register.html',1,'vn::sensors']]],
  ['dimension_5ferror',['dimension_error',['../classvn_1_1dimension__error.html',1,'vn']]]
];
