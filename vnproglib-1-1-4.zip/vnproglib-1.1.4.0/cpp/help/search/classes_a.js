var searchData=
[
  ['observer',['Observer',['../classvn_1_1xplat_1_1_signal_1_1_observer.html',1,'vn::xplat::Signal']]]
];
